CREATE TABLE IF NOT EXISTS sources (
    source_code VARCHAR(30) PRIMARY KEY,
    rating_scale_max NUMERIC(4,2),

    CONSTRAINT chk_source_code
    CHECK (
        source_code IN (
            'foody',
            'tripadvisor',
            'eatigo',
            'capichi'
        )
    )
);


CREATE TABLE IF NOT EXISTS restaurants (
    source_code VARCHAR(30) NOT NULL,
    source_restaurant_id TEXT NOT NULL,

    name TEXT,
    url TEXT,
    city TEXT,
    address TEXT,
    category TEXT,
    location TEXT,

    avg_rating NUMERIC(4,2),
    total_reviews INTEGER,

    latitude NUMERIC(9,6),
    longitude NUMERIC(9,6),

    price_range TEXT,
    telephone TEXT,

    crawl_timestamp TIMESTAMPTZ NOT NULL,
    raw_object_key TEXT NOT NULL,

    PRIMARY KEY (
        source_code,
        source_restaurant_id
    ),

    FOREIGN KEY (source_code)
        REFERENCES sources(source_code)
);


CREATE TABLE IF NOT EXISTS restaurant_opening_hours (
    source_code VARCHAR(30) NOT NULL,
    source_restaurant_id TEXT NOT NULL,

    day_of_week SMALLINT NOT NULL,
    open_time TIME,
    close_time TIME,

    PRIMARY KEY (
        source_code,
        source_restaurant_id,
        day_of_week
    ),

    FOREIGN KEY (
        source_code,
        source_restaurant_id
    )
        REFERENCES restaurants(
            source_code,
            source_restaurant_id
        )
        ON DELETE CASCADE,

    CHECK (
        day_of_week
        BETWEEN 1 AND 7
    )
);


CREATE TABLE IF NOT EXISTS restaurant_cuisines (
    source_code VARCHAR(30) NOT NULL,
    source_restaurant_id TEXT NOT NULL,
    cuisine TEXT NOT NULL,

    PRIMARY KEY (
        source_code,
        source_restaurant_id,
        cuisine
    ),

    FOREIGN KEY (
        source_code,
        source_restaurant_id
    )
        REFERENCES restaurants(
            source_code,
            source_restaurant_id
        )
        ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS reviewers (
    source_code VARCHAR(30) NOT NULL,
    reviewer_id TEXT NOT NULL,

    reviewer_name TEXT,
    total_reviews INTEGER,
    total_pictures INTEGER,

    trust_percent NUMERIC(5,2),
    verifying_percent NUMERIC(5,2),
    is_verified BOOLEAN,

    PRIMARY KEY (
        source_code,
        reviewer_id
    ),

    FOREIGN KEY (source_code)
        REFERENCES sources(source_code)
);


CREATE TABLE IF NOT EXISTS reviews (
    source_code VARCHAR(30) NOT NULL,
    source_review_id TEXT NOT NULL,
    source_restaurant_id TEXT NOT NULL,

    reviewer_id TEXT,
    reviewer_name_raw TEXT,

    review_title TEXT,
    review_text TEXT,
    rating NUMERIC(4,2),

    review_date TIMESTAMPTZ,
    travel_date DATE,
    language VARCHAR(10),
    device_name TEXT,

    total_views INTEGER,
    total_pictures INTEGER,
    total_likes INTEGER,
    total_comments INTEGER,

    guest_count TEXT,
    visit_again TEXT,
    money_spend TEXT,

    feature_depth_status TEXT,

    PRIMARY KEY (
        source_code,
        source_review_id
    ),

    FOREIGN KEY (
        source_code,
        source_restaurant_id
    )
        REFERENCES restaurants(
            source_code,
            source_restaurant_id
        )
        ON DELETE CASCADE,

    FOREIGN KEY (
        source_code,
        reviewer_id
    )
        REFERENCES reviewers(
            source_code,
            reviewer_id
        )
);


CREATE TABLE IF NOT EXISTS review_tags (
    source_code VARCHAR(30) NOT NULL,
    source_review_id TEXT NOT NULL,
    tag TEXT NOT NULL,

    PRIMARY KEY (
        source_code,
        source_review_id,
        tag
    ),

    FOREIGN KEY (
        source_code,
        source_review_id
    )
        REFERENCES reviews(
            source_code,
            source_review_id
        )
        ON DELETE CASCADE
);


CREATE INDEX IF NOT EXISTS
    idx_restaurants_city
ON restaurants(city);


CREATE INDEX IF NOT EXISTS
    idx_reviews_restaurant
ON reviews(
    source_code,
    source_restaurant_id
);


CREATE INDEX IF NOT EXISTS
    idx_reviews_review_date
ON reviews(review_date);


INSERT INTO sources (
    source_code,
    rating_scale_max
)
VALUES
    ('foody', 10),
    ('tripadvisor', 5),
    ('eatigo', 5),
    ('capichi', 5)
ON CONFLICT (source_code)
DO UPDATE SET
    rating_scale_max =
        EXCLUDED.rating_scale_max;
